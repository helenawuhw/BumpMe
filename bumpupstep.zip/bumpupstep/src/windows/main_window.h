#pragma once

#include <pebble.h>

#include "../modules/health.h"

void main_window_push();

void main_window_update_ui();
